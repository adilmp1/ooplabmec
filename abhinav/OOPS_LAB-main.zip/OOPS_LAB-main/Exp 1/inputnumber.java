import java.util.Scanner;

class inputnumber{
    public static void main(String args[]){
        Scanner read = new Scanner(System.in);
        System.out.println("Enter your no.: ");
        int num = read.nextInt();
        System.out.println("Your Entered no. is : "+ num);
    }
}